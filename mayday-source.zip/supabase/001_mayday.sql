-- Run once in the dedicated Mayday project's SQL editor.
-- No email address or password is embedded in this public source.
begin;
create schema if not exists mayday_private;
revoke all on schema mayday_private from public, anon, authenticated;
create table mayday_private.owners (user_id uuid primary key references auth.users(id) on delete cascade);
create function public.mayday_is_owner() returns boolean language sql stable security definer
set search_path = '' as $$
 select exists(select 1 from mayday_private.owners o join auth.users u on u.id=o.user_id
 where o.user_id=auth.uid() and u.email_confirmed_at is not null);
$$;
revoke all on function public.mayday_is_owner() from public;
grant execute on function public.mayday_is_owner() to anon, authenticated;
create table public.mayday_news (
 id uuid primary key default gen_random_uuid(), translations jsonb not null,
 archived boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 constraint translations_object check(jsonb_typeof(translations)='object' and translations ?& array['ru','uk','en']));
create table public.mayday_materials (
 id uuid primary key default gen_random_uuid(), title text not null check(length(title) between 1 and 180),
 language text not null check(language in ('ru','uk','en')), object_key text unique not null,
 size bigint not null check(size between 1 and 12582912), archived boolean not null default false,
 updated_at timestamptz not null default now());
create table public.mayday_settings (key text primary key check(key in ('content','brand','logo','heroWide','heroMobile')), value jsonb not null);
alter table public.mayday_news enable row level security;
alter table public.mayday_materials enable row level security;
alter table public.mayday_settings enable row level security;
revoke all on public.mayday_news,public.mayday_materials,public.mayday_settings from anon,authenticated;
grant select on public.mayday_news,public.mayday_materials,public.mayday_settings to anon,authenticated;
grant insert,update on public.mayday_news,public.mayday_materials,public.mayday_settings to authenticated;
create policy news_read on public.mayday_news for select using(not archived or public.mayday_is_owner());
create policy news_insert on public.mayday_news for insert to authenticated with check(public.mayday_is_owner());
create policy news_update on public.mayday_news for update to authenticated using(public.mayday_is_owner()) with check(public.mayday_is_owner());
create policy materials_read on public.mayday_materials for select using(not archived or public.mayday_is_owner());
create policy materials_insert on public.mayday_materials for insert to authenticated with check(public.mayday_is_owner());
create policy materials_update on public.mayday_materials for update to authenticated using(public.mayday_is_owner()) with check(public.mayday_is_owner());
create policy settings_read on public.mayday_settings for select using(true);
create policy settings_insert on public.mayday_settings for insert to authenticated with check(public.mayday_is_owner());
create policy settings_update on public.mayday_settings for update to authenticated using(public.mayday_is_owner()) with check(public.mayday_is_owner());
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values
 ('mayday-images','mayday-images',true,8388608,array['image/png','image/jpeg','image/webp']),
 ('mayday-pdfs','mayday-pdfs',false,12582912,array['application/pdf']);
create policy mayday_image_read on storage.objects for select using(bucket_id='mayday-images');
create policy mayday_pdf_read on storage.objects for select using(bucket_id='mayday-pdfs' and
 (public.mayday_is_owner() or exists(select 1 from public.mayday_materials m where m.object_key=name and not m.archived)));
create policy mayday_upload on storage.objects for insert to authenticated with check(bucket_id in ('mayday-images','mayday-pdfs') and public.mayday_is_owner());
-- Only used to clean up an upload when the following metadata save fails.
create policy mayday_cleanup on storage.objects for delete to authenticated using(bucket_id in ('mayday-images','mayday-pdfs') and public.mayday_is_owner());
commit;
