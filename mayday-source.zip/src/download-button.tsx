import {useState} from 'react';
import {downloadMaterial} from './api';
import {cmsCopy} from './cms-i18n';
import {type Lang} from './i18n';
export default function DownloadButton({id,lang,title}:{id:string;lang:Lang;title?:string}){const[busy,setBusy]=useState(false);const[error,setError]=useState(false);const t=cmsCopy[lang];return <div><button disabled={busy} className="download-button" onClick={async()=>{setBusy(true);setError(false);try{await downloadMaterial(id)}catch{setError(true)}finally{setBusy(false)}}}>{busy?t.loading:title||t.download}</button>{error&&<p role="alert">{t.error}</p>}</div>}
