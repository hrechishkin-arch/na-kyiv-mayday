import {createClient} from '@supabase/supabase-js';
const url=import.meta.env.VITE_SUPABASE_URL;
const key=import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
// Only the public project key belongs in the static build. Authorization is in RLS.
export const supabase=url&&key?createClient(url,key,{auth:{flowType:'pkce',detectSessionInUrl:true,persistSession:true,autoRefreshToken:true}}):null;
export function client(){if(!supabase)throw Error('not_configured');return supabase}
export function pageLink(page:string,lang='ru'){return `./?page=${page.replace(/^\//,'')||'home'}&lang=${lang}`}
export function callbackUrl(){return new URL('./?page=admin',location.href).href}
