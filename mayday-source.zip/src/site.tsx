'use client';
import {useEffect,useState} from 'react';
import {ArrowUpRight,BookOpen,Newspaper,ArrowRight} from 'lucide-react';
import {copy,languages,type Lang} from './i18n';
import AuthPanel from './auth-panel';
import DownloadButton from './download-button';
import {api} from './api';
import {pageLink} from './supabase';
import {cmsCopy} from './cms-i18n';
import {defaultContent,defaultAppearance,type SiteSettings,type Material} from './cms-shared';

export type Post={id:string;translations:Record<Lang,{title:string;body:string}>;created_at:string;updated_at:string};
export default function Site({section,editor=false,authenticated=false,userId}:{section:'home'|'news'|'literature'|'admin';editor?:boolean;authenticated?:boolean;userId?:string}){
const [settings,setSettings]=useState<SiteSettings>({content:defaultContent,appearance:defaultAppearance});const [materials,setMaterials]=useState<Material[]>([]);const [materialState,setMaterialState]=useState('loading');
const [lang,setLang]=useState<Lang>('ru');const [posts,setPosts]=useState<Post[]>([]);const [status,setStatus]=useState('loading');
useEffect(()=>{const l=new URLSearchParams(location.search).get('lang');if(languages.includes(l as Lang))setLang(l as Lang)},[]);
useEffect(()=>{document.documentElement.lang=lang;document.title=`${settings.appearance.brand} — ${settings.content[lang].name} · ${settings.content[lang].city}`},[lang,settings]);
async function reload(){setStatus('loading');try{setPosts(await api('/api/news'));setStatus('ok')}catch{setStatus('error')}}
useEffect(()=>{if(section==='news'||section==='admin')reload()},[section]);
useEffect(()=>{api('/api/site').then(s=>setSettings(s as SiteSettings)).catch(()=>{});if(section==='literature'){api('/api/literature').then(r=>{setMaterials(r as Material[]);setMaterialState('ok')}).catch(()=>setMaterialState('error'))}},[section]);
const t={...copy[lang],...settings.content[lang]};const a=settings.appearance;const c=cmsCopy[lang];const href=(path:string)=>pageLink(path,lang);
function language(l:Lang){setLang(l);const u=new URL(location.href);u.searchParams.set('lang',l);history.replaceState(null,'',u)}
return <><a className="skip" href="#main">{t.skip}</a><header className="header"><a className="brand" href={href('/')} >{a.logo&&<img src={a.logo} alt=""/>}<span>{a.brand}<small>{t.name} · {t.city}</small></span></a><nav aria-label={t.home}>{(['home','literature','news'] as const).map(s=><a aria-current={section===s?'page':undefined} key={s} href={href(s==='home'?'/':`/${s}`)}>{t[s]}</a>)}</nav><div className="languages" aria-label={lang==="ru"?"Язык":lang==="uk"?"Мова":"Language"}>{languages.map(l=><button key={l} lang={l} aria-pressed={l===lang} onClick={()=>language(l)}>{l==='uk'?'УКР':l==='ru'?'РУС':'ENG'}</button>)}</div></header>
<main id="main">{section==='home'?<><section className="hero"><picture className="hero-art"><source media="(max-width: 760px)" srcSet={a.heroMobile}/><img src={a.heroWide} alt={a.brand} fetchPriority="high"/></picture><div className="hero-inner"><p className="eyebrow">{t.eyebrow}</p><h1>{t.hero}</h1><div className="hero-bottom"><p>{t.intro}</p><a className="button light" href={href('/literature')}>{t.read}<ArrowUpRight size={20}/></a></div></div></section><section className="resources"><div className="section-label">01 / {t.literature}</div><a className="resource-link" href={href('/literature')}><BookOpen/><div><h2>{t.resources}</h2><p>{t.resourceText}</p></div><ArrowUpRight/></a><div className="section-label">02 / {t.news}</div><a className="resource-link" href={href('/news')}><Newspaper/><div><h2>{t.latest}</h2><p>{t.newsText}</p></div><ArrowUpRight/></a></section></>:<section className="page"><p className="eyebrow">{t.city}</p><h1>{section==='admin'?c.panel:t[section]}</h1><p className="page-intro">{section==='literature'?t.resourceText:section==='news'?t.newsText:''}</p>
{section==='literature'&&(materialState==='loading'?<p>{c.loading}</p>:materialState==='error'?<p role="alert">{c.error} <button onClick={()=>location.reload()}>{c.retry}</button></p>:materials.filter(b=>b.language===lang).length?materials.filter(b=>b.language===lang).map(b=><div className="resource-link" key={b.id}><BookOpen/><h2>{b.title}</h2><DownloadButton id={b.id} lang={lang}/></div>):<Empty icon="book" title={t.emptyBooks} text={t.emptyBooksText}/>)}
{section==='admin'&&<AuthPanel lang={lang}/>}
{section==='news'&&<div aria-live="polite">{status==='loading'?<p>{t.loading}</p>:status==='error'?<div className="empty"><p>{t.error}</p><button onClick={reload}>{t.retry}</button></div>:posts.length===0?<Empty icon="news" title={t.emptyNews} text={t.emptyNewsText}/>:posts.map(p=><article className="article" key={p.id}><time dateTime={p.created_at}>{new Date(p.created_at).toLocaleDateString(lang==='uk'?'uk-UA':lang==='ru'?'ru-UA':'en-GB',{day:'numeric',month:'long',year:'numeric'})}</time><h2>{p.translations[lang].title}</h2><p>{p.translations[lang].body}</p></article>)}</div>}</section>}</main><footer><div><strong>{a.brand} · {t.name}</strong><span>{t.city}</span></div><a href={href('/admin')}>{c.panel}<ArrowRight size={16}/></a></footer></>}
function Empty({icon,title,text}:{icon:string;title:string;text:string}){return <div className="empty">{icon==='book'?<BookOpen size={30}/>:<Newspaper size={30}/>}<h2>{title}</h2><p>{text}</p></div>}

