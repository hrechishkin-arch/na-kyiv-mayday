import React from 'react';
import {createRoot} from 'react-dom/client';
import Site from './site';
import './globals.css';
const page=new URLSearchParams(location.search).get('page');
const section=page==='news'||page==='literature'||page==='admin'?page:'home';
createRoot(document.getElementById('root')!).render(<React.StrictMode><Site section={section}/></React.StrictMode>);
