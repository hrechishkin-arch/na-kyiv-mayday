import type {Lang} from './i18n';
export type LocalText=Record<Lang,string>;
export const emptyText=():LocalText=>({ru:'',uk:'',en:''});
export const localText=(value:LocalText,lang:Lang)=>value[lang]||value.uk||value.ru||value.en||'';
export type Meeting={id:string;name:LocalText;schedule:LocalText;format:LocalText;details:LocalText};
export type Product={id:string;name:LocalText;description:LocalText;image:string;price:string;currency:string;available:boolean};
export type Community={meetings:Meeting[];address:LocalText;mapQuery:string;sellerName:string;sellerContact:string;products:Product[]};
export const newMeeting=():Meeting=>({id:crypto.randomUUID(),name:emptyText(),schedule:emptyText(),format:emptyText(),details:emptyText()});
export const defaultCommunity:Community={meetings:[{id:'group-1',name:{ru:'Mayday',uk:'Mayday',en:'Mayday'},schedule:emptyText(),format:emptyText(),details:emptyText()},{id:'group-2',name:{ru:'Mayday online',uk:'Mayday online',en:'Mayday online'},schedule:emptyText(),format:emptyText(),details:emptyText()}],address:{ru:'Киев, Круглоуниверситетская, 7',uk:'Київ, Круглоуніверситетська, 7',en:'7 Kruh­louniversytetska Street, Kyiv'},mapQuery:'Київ, Круглоуніверситетська вулиця, 7',sellerName:'',sellerContact:'',products:[]};
export const communityCopy={
 ru:{schedule:'Расписание собраний',shop:'Сувенирка',telegram:'Перейти в Telegram',location:'Как нас найти',route:'Построить маршрут',map:'Показать карту Google',empty:'Расписание скоро появится',emptyShop:'Сувениры скоро появятся',format:'Формат',when:'Когда',contact:'Заказать / связаться',seller:'По вопросам покупки',sold:'Нет в наличии',price:'Цена уточняется',original:'Текст на языке оригинала'},
 uk:{schedule:'Розклад зібрань',shop:'Сувеніри',telegram:'Перейти в Telegram',location:'Як нас знайти',route:'Прокласти маршрут',map:'Показати карту Google',empty:'Розклад незабаром з’явиться',emptyShop:'Сувеніри незабаром з’являться',format:'Формат',when:'Коли',contact:'Замовити / зв’язатися',seller:'З питань придбання',sold:'Немає в наявності',price:'Ціна уточнюється',original:'Текст мовою оригіналу'},
 en:{schedule:'Meeting schedule',shop:'Merchandise',telegram:'Join us on Telegram',location:'Find us',route:'Get directions',map:'Show Google Map',empty:'The schedule is coming soon',emptyShop:'Merchandise is coming soon',format:'Format',when:'When',contact:'Order / contact',seller:'Purchase enquiries',sold:'Out of stock',price:'Contact for price',original:'Text in its original language'}
};
export function contactUrl(value:string){const v=value.trim();if(/^@[a-zA-Z0-9_]{5,32}$/.test(v))return 'https://t.me/'+v.slice(1);if(/^\+?[\d\s()-]{7,25}$/.test(v))return 'tel:'+v.replace(/[\s()-]/g,'');try{const u=new URL(v);return u.protocol==='https:'?u.href:''}catch{return ''}}
export function imageUrl(value:string){try{const u=new URL(value);return u.protocol==='https:'?u.href:''}catch{return ''}}
