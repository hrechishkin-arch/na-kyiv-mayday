import {copy,type Lang} from './i18n';
export const editableKeys=['name','city','home','literature','news','eyebrow','hero','intro','read','latest','resources','resourceText','newsText','emptyBooks','emptyBooksText','emptyNews','emptyNewsText','download'] as const;
export type ContentKey=typeof editableKeys[number];
export type SiteContent=Record<Lang,Record<ContentKey,string>>;
export const defaultContent=Object.fromEntries(Object.entries(copy).map(([lang,text])=>[lang,Object.fromEntries(editableKeys.map(key=>[key,text[key]]))])) as SiteContent;
export const defaultAppearance={brand:'Mayday',logo:'./mayday-logo.png',heroWide:'./mayday-hero-wide.png',heroMobile:'./mayday-hero-mobile.png'};
export type Appearance=typeof defaultAppearance;
export type SiteSettings={content:SiteContent;appearance:Appearance};
export type Material={id:string;title:string;language:Lang;size:number;archived:number;updated_at:string};
