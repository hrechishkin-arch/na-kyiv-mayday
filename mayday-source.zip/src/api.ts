import {client} from './supabase';
import {defaultContent,defaultAppearance,type SiteSettings} from './cms-shared';
import {languages} from './i18n';
function checked<T>({data,error}:{data:T;error:unknown}):T{if(error)throw Error('unavailable');return data}
function validText(value:unknown,max:number){if(typeof value!=='string'||!value.trim()||value.length>max)throw Error('invalid');return value.trim()}
async function setting(key:string,value:unknown){checked(await client().from('mayday_settings').upsert({key,value}));}
export async function getSettings():Promise<SiteSettings>{
 const rows=checked(await client().from('mayday_settings').select('*'));
 const result:SiteSettings={content:structuredClone(defaultContent),appearance:{...defaultAppearance}};
 for(const row of rows||[]){if(row.key==='content')result.content=row.value;else if(row.key in result.appearance)(result.appearance as any)[row.key]=row.value;}
 return result;
}
export async function api(url:string,options:RequestInit={}){
 const db=client(),method=options.method||'GET',all=url.includes('all=1');
 if(url==='/api/site'){
  if(method==='GET')return getSettings();
  const data=JSON.parse(String(options.body));
  if(data.section==='brand'){await setting('brand',validText(data.brand,80));return {ok:true}}
  for(const lang of languages)for(const key of Object.keys(defaultContent[lang]))validText(data.content?.[lang]?.[key],2000);
  await setting('content',data.content);return {ok:true};
 }
 if(url.startsWith('/api/news')){
  if(method==='GET'){let q=db.from('mayday_news').select('*').order('created_at',{ascending:false});if(!all)q=q.eq('archived',false);return checked(await q)}
  const data=JSON.parse(String(options.body));
  if(method==='PATCH')return checked(await db.from('mayday_news').update({archived:!!data.archived,updated_at:new Date().toISOString()}).eq('id',data.id).select().single());
  for(const lang of languages){validText(data.translations?.[lang]?.title,180);validText(data.translations?.[lang]?.body,20000)}
  const row={translations:data.translations,updated_at:new Date().toISOString()};
  return checked(await (method==='POST'?db.from('mayday_news').insert(row):db.from('mayday_news').update(row).eq('id',data.id)).select().single());
 }
 if(url.startsWith('/api/literature')){
  if(method==='GET'){let q=db.from('mayday_materials').select('*').order('updated_at',{ascending:false});if(!all)q=q.eq('archived',false);return checked(await q)}
  if(method==='PATCH'){const data=JSON.parse(String(options.body));return checked(await db.from('mayday_materials').update({archived:!!data.archived,updated_at:new Date().toISOString()}).eq('id',data.id).select().single())}
  const form=options.body as FormData,id=String(form.get('id')||''),title=validText(form.get('title'),180),language=String(form.get('language'));
  if(!languages.includes(language as any))throw Error('invalid');
  const file=form.get('file');let path:string|undefined;
  const row:Record<string,unknown>={title,language,updated_at:new Date().toISOString()};
  if(file instanceof File){await validateFile(file,'pdf');path=crypto.randomUUID()+'.pdf';checked(await db.storage.from('mayday-pdfs').upload(path,file,{contentType:'application/pdf',upsert:false}));row.object_key=path;row.size=file.size}
  if(!id&&!path)throw Error('invalid');
  try{return checked(await (id?db.from('mayday_materials').update(row).eq('id',id):db.from('mayday_materials').insert(row)).select().single())}
  catch(e){if(path)await db.storage.from('mayday-pdfs').remove([path]);throw e}
 }
 if(url==='/api/manage/images'){
  const form=options.body as FormData,slot=String(form.get('slot')),file=form.get('file');
  if(!['logo','heroWide','heroMobile'].includes(slot)||!(file instanceof File))throw Error('invalid');
  const mime=await validateFile(file,'image'),path=crypto.randomUUID()+({ 'image/png':'.png','image/jpeg':'.jpg','image/webp':'.webp'} as Record<string,string>)[mime];
  checked(await db.storage.from('mayday-images').upload(path,file,{contentType:mime,upsert:false}));
  try{await setting(slot,db.storage.from('mayday-images').getPublicUrl(path).data.publicUrl)}catch(e){await db.storage.from('mayday-images').remove([path]);throw e}
  return {ok:true};
 }
 throw Error('unavailable');
}
export async function validateFile(file:File,kind:'image'|'pdf'){
 if(file.size>(kind==='pdf'?12:8)*1048576)throw Error('too_large');
 const b=new Uint8Array(await file.slice(0,12).arrayBuffer()),s=String.fromCharCode(...b);
 if(kind==='pdf'){if(!s.startsWith('%PDF-'))throw Error('invalid');return 'application/pdf'}
 if(b[0]===137&&s.slice(1,4)==='PNG'&&b[4]===13&&b[5]===10&&b[6]===26&&b[7]===10)return 'image/png';
 if(b[0]===255&&b[1]===216&&b[2]===255)return 'image/jpeg';
 if(s.startsWith('RIFF')&&s.slice(8,12)==='WEBP')return 'image/webp';
 throw Error('invalid');
}
export async function downloadMaterial(id:string){
 const db=client(),row=checked(await db.from('mayday_materials').select('object_key,title').eq('id',id).single());
 if(!row)throw Error('unavailable');
 // The bucket is private. RLS also applies to downloads, including archived files.
 const blob=checked(await db.storage.from('mayday-pdfs').download(row.object_key));
 if(!blob)throw Error('unavailable');
 const url=URL.createObjectURL(blob),anchor=document.createElement('a');anchor.href=url;anchor.download=row.title.replace(/[<>:"/\\|?*]/g,'_')+'.pdf';anchor.click();setTimeout(()=>URL.revokeObjectURL(url),60000);
}
