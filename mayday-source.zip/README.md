# Mayday — GitHub Pages

Published site: https://hrechishkin-arch.github.io/na-kyiv-mayday/
Owner sign-in: https://hrechishkin-arch.github.io/na-kyiv-mayday/?page=admin&lang=ru

React + Vite static site. Supabase provides email/password authentication, owner authorization (RLS), content and file storage. Production serves the compiled files from repository root; the source is included in mayday-source.zip. No private credentials belong in the source or build.

## Build and tests

Use Node 22 or newer. Install with npm ci, run npm test, then npm run build. Vite uses relative asset paths. The current upload process flattens dist/assets into the repository root and rewrites index.html accordingly. Upload index.html, the referenced JS/CSS, public assets when changed, and a refreshed source archive. Preserve .nojekyll.

.env.local contains VITE_SUPABASE_URL and the public VITE_SUPABASE_PUBLISHABLE_KEY. Never include .env.local in archives. .env.example documents the public fields.

## Owner editing

- News: write in one language; optional manual translations in language tabs. Missing translations show the original and a notice. Automatic translation is not connected, by the owner's choice.
- Literature: PDF upload, language, replacement, archive/restore.
- Meeting schedule: two groups, Mayday and Mayday online; editable names, times, formats, details, displayed address and map address. All times are Kyiv local time. Times and formats are intentionally blank until provided.
- Merchandise: image uploads, multilingual name/description, price/currency, availability, catalogue removal, and shared sales contact. Orders use the contact link; there is no checkout or payment processing.
- Site copy, brand, and images are editable as before. The owner link is only shown after authenticated owner verification; direct sign-in remains available.

Schedule and merchandise are stored under _community in the existing mayday_settings content document. No new migration is required. RLS for owner-only writes is unchanged. Content writes carry a _revision marker and reject concurrent writes detected between read and save. Product image uploads use the existing mayday-images bucket; failed saves attempt cleanup. Removed catalogue images are retained.

The main button links to https://t.me/mayday_NA_online. Google Maps uses the configurable address and includes a separate directions link. Maps availability depends on Google and the visitor's browser/network.

## Setup still requiring owner verification

After repository rename, Supabase Authentication > URL Configuration must use the new site URL and redirect URL https://hrechishkin-arch.github.io/na-kyiv-mayday/?page=admin. The owner was given these values; saving them has not been verified.

Owner confirmed that email verification and owner access worked before the rename. Editing flows are covered by mocked API/form tests; this release has not been tested by signing in as the production owner. Default Supabase email sending has previously reached its rate limit; custom SMTP is not configured.

The old chatgpt.site deployment is separate and has not received these GitHub changes.


## Baseline snapshot

Frozen as source on 2026-09-19 (commit 1757caf). Public site plus owner-panel workspace styles. Schedule and shop kept.
