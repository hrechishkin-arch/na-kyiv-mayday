# Mayday: GitHub Pages + Supabase

Prepared migration; not deployed. This folder is the standalone repository root.
The existing Sites project outside this folder remains intact.

## Service setup (not completed)

1. Create a dedicated Supabase project in the owner's account. The owner enters the database password personally. Select a plan only with the owner's approval.
2. Execute `supabase/001_mayday.sql` once. It creates new namespaced tables, private owner mapping, RLS and two storage buckets; it does not copy the old site's data.
3. Enable email confirmation and configure SMTP for confirmation/recovery mail. Keep passwords at least 12 characters. Configure the exact GitHub Pages URL as Site URL and its `?page=admin` callback as an allowed redirect.
4. Add only the project URL and publishable key to the GitHub repository Variables named in `.env.example`. Never place a service-role key, personal access token, database password, or SMTP secret in the repository or frontend.
5. The owner registers using their own email and site-specific password, then verifies their email. An administrator must verify that identity in Supabase and insert that user's UUID into `mayday_private.owners`. Clients have no permission to populate or modify this table. Never assign ownership merely by a submitted email address.
6. Export and compare existing Sites news and materials before cutover; copy real records and files, preserving IDs/timestamps where possible. Do not treat unavailable APIs as empty content.
7. Configure GitHub Pages to deploy via Actions. Upload only this standalone directory, not the parent project or local environment files. The repository must be public for GitHub Free Pages.

## Development

Node 22.13+; `npm ci`, `npm run dev`, `npm run build`.
Copy `.env.example` to `.env.local` and supply public project configuration for local testing.
Routes use `?page=home|news|literature|admin`, so the same build works below a repository subpath and on a custom domain.

## Before publication

- Verify anonymous reads of published content, denial of all anonymous mutations, and denial for a second signed-in non-owner account.
- Verify owner CRUD, unpublish/restore, PDF replacement/download and image updates on the real project.
- Verify email confirmation, password recovery, sign-out, and expired sessions on the deployed origin.
- Check desktop/mobile presentation and all three languages.
- All HTML includes `noindex,nofollow,noarchive`. PDFs stay in a private bucket and download as browser blobs; they have no public permanent download links. GitHub Pages cannot add arbitrary response headers. If a strict `X-Robots-Tag` requirement on PDF responses remains, implement and verify a Supabase Edge Function serving them with that header before cutover.
- Keep the existing Sites deployment accessible until the new deployment is verified and the owner has successfully signed in.

## Current verification

TypeScript and production build pass. Dependency audit reports zero vulnerabilities after updating Vite. Actual authentication, RLS and storage operations still require a connected Supabase project; not yet verified.
